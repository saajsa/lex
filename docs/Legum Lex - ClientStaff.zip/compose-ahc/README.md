# Agreement Health Check — Details screen · Jetpack Compose (Material 3)

Single client-facing Android screen for **Legum Lex**: what a client sees after
submitting an agreement through the Agreement Health Check (AHC) funnel. One
screen, every lifecycle state, built as reusable composables on the in-place
**claret / serif / warm-paper** design system (see `Agreement Check Workflow.html`).

Light theme only. Color carries meaning only (risk severity, status); body stays
ink-on-paper.

---

## File map (`com.legumlex.client.ahc`)

| File | What's in it |
|---|---|
| `theme/Tokens.kt` | Color palette, `RiskLevel` & `FindingSeverity` palette maps, dimens, shapes |
| `theme/Type.kt` | `SourceSerif` / `PlexSans` / `PlexMono` families + semantic `LlText` styles |
| `theme/Theme.kt` | `LegumLexTheme` — light-only M3 wrapper |
| `model/AhcModels.kt` | `AhcUiState` sealed type + data classes + `AhcActions` callbacks |
| `components/Primitives.kt` | `LlCard`, `AhcTopBar`, `SectionHeader`, buttons, `StatusChip`, `LlAvatar`, `AdvocateRow` |
| `components/SignalComponents.kt` | `FindingList`, `RecommendationList`, `KeyTermsCard`, `ActivityTimeline`, `SubmittedDocRow` |
| `components/CountdownCard.kt` | SLA ring (Canvas) + calm overdue variant |
| `components/FeatureCards.kt` | `RiskHero`, `AdvocateNoteCard`, `WhatHappensNext`, `ContextStrip`, `PartialFailureBlock` |
| `AhcDetailScreen.kt` | The screen — `when`s over `AhcUiState` for all states |
| `SampleData.kt` | Real-data fixtures (Adv. Anjali Rao, TechNova, ₹ INR, IST) |
| `Previews.kt` | `@Preview` for every required state |

Drop the package into `app/src/main/java/com/legumlex/client/ahc/` (the folder
here is flattened for review — keep the `theme/`, `model/`, `components/`
sub-packages).

---

## Entry point

```kotlin
AhcDetailScreen(
    state = viewModel.uiState,          // AhcUiState
    actions = AhcActions(
        onBack = { … },
        onPreviewAgreement = { … },     // only wired when has_document
        onTalkToAdvocate = { … },
        onBookConsultation = { … },
        // …
    ),
)
```

`AhcUiState` is one of: `Loading` · `Pending` (+ overdue) · `Released`
(primary) · `Escalated` · `Empty` · `Error`. Map the backend
`consultations/ahc/{id}` + consultation row into it in your ViewModel.

---

## Token → element annotations

Every colored element references a token, never a raw hex:

- **Risk hero** — `RiskLevel.{solid, soft, border}`: LOW → Verdant, MEDIUM →
  Amber, HIGH·CRITICAL → Claret. The score is shown as-is; the **level enum is
  authoritative for color**.
- **Finding stripe** — `FindingSeverity.stripe`: CRITICAL → Claret, WARN →
  AmberMid, OK → Verdant.
- **Countdown ring** — Verdant track→fill while on time, flips to **AmberMid**
  in the final ~5 minutes; overdue uses **AmberSoft / Amber** (calm, no alarm).
- **Advocate's note** — Claret left-rule on released; **SlateMid** when the
  state is escalated (`AdvocateNoteCard(accent = …)`).
- **Escalation panel & context strip** — Slate palette (`SlateSoft` / `Slate`).
- **App-bar status eyebrow** — Verdant "Released", Slate "Escalated", Amber
  "Running late".
- **Neutral spine** everywhere else: `Ink` / `InkMuted` / `InkFaint` text,
  `Paper` bg, `Surface` cards, `Border` hairlines.

---

## ⚠️ Risk-score direction

The visual system displays `risk_score` as a 0–100 **health** score where
**higher = safer** (88/100 == "Low risk"). The brief's `risk_level` band table
(`LOW ≤30 … CRITICAL >80`) reads as risk **magnitude** (higher = worse) — the
opposite direction.

We resolved this by making **`risk_level` authoritative for color** and showing
the number as-is. If your backend sends magnitude, only
`RiskLevel.fromMagnitude(score)` changes; the palette mapping is untouched.
Confirm the direction with backend before shipping.

---

## Setup notes

**Fonts** — `Type.kt` references `R.font.*` ids for Source Serif 4, IBM Plex
Sans, IBM Plex Mono. Add the font files to `res/font/` with the names used in
`Type.kt`, or swap the `Font(...)` lines for a `GoogleFont` provider.

**Icons** — Material Icons (`androidx.compose.material:material-icons-extended`)
stand in for the Material Symbols glyphs from the web mock; closest-equivalent
names are noted in comments (e.g. `Description` ← `draft`, `RecordVoiceOver`,
`HourglassTop`). Swap for your icon set if you ship custom glyphs.

**Dependencies** — Compose BOM, `material3`, `material-icons-extended`,
`ui-tooling` (for `@Preview`).

---

## Reviewing the states

Open `Previews.kt` in Android Studio's preview pane. Twelve previews cover:
pending (fresh / halfway), overdue, released (LOW / MODERATE / HIGH / partial
failure), escalated (awaiting / booked), loading, empty, error.
