package com.legumlex.client.ahc.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

/* ============================================================================
 *  LegumLexTheme — LIGHT ONLY. We hand the M3 color scheme our warm-paper
 *  spine so any stock Material component inherits the brand. The bespoke AHC
 *  composables read LlColor / LlText directly rather than the M3 scheme.
 *
 *  Dark mode is intentionally unsupported on the client app (legal-professional,
 *  print-like surface). We ignore isSystemInDarkTheme() and stay light.
 * ========================================================================== */

private val LlLightScheme = lightColorScheme(
    primary          = LlColor.Ink,          // primary action = ink button
    onPrimary        = LlColor.Paper,
    secondary        = LlColor.Claret,        // brand accent
    onSecondary      = LlColor.Paper,
    background        = LlColor.Paper,
    onBackground      = LlColor.Ink,
    surface          = LlColor.Surface,
    onSurface        = LlColor.Ink,
    surfaceVariant   = LlColor.Paper1,
    onSurfaceVariant = LlColor.InkMuted,
    outline          = LlColor.Border,
    outlineVariant   = LlColor.BorderStrong,
    error            = LlColor.ClaretMid,
    onError          = LlColor.Paper,
)

@Composable
fun LegumLexTheme(content: @Composable () -> Unit) {
    @Suppress("UNUSED_VARIABLE")
    val ignoredDark = isSystemInDarkTheme() // deliberately not applied — light only
    MaterialTheme(
        colorScheme = LlLightScheme,
        typography = LlTypography,
        content = content,
    )
}
