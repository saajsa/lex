package com.legumlex.client.ahc.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.legumlex.client.ahc.R

/* ============================================================================
 *  Typography — three families, used with intent:
 *    Serif  · Source Serif 4   → titles, verdict labels, advocate's note body
 *    Sans   · IBM Plex Sans    → all UI / body / buttons / chips
 *    Mono   · IBM Plex Mono    → metadata, scores, timestamps, reference codes
 *
 *  Drop the variable/static font files into res/font/ with these names, or
 *  swap the Font(...) lines for GoogleFont(...) providers. Until then these
 *  resolve at compile time against the R.font ids below.
 * ========================================================================== */

val SourceSerif = FontFamily(
    Font(R.font.source_serif_4_light,    FontWeight.Light),
    Font(R.font.source_serif_4_regular,  FontWeight.Normal),
    Font(R.font.source_serif_4_medium,   FontWeight.Medium),
    Font(R.font.source_serif_4_semibold, FontWeight.SemiBold),
    Font(R.font.source_serif_4_bold,     FontWeight.Bold),
)

val PlexSans = FontFamily(
    Font(R.font.ibm_plex_sans_light,    FontWeight.Light),
    Font(R.font.ibm_plex_sans_regular,  FontWeight.Normal),
    Font(R.font.ibm_plex_sans_medium,   FontWeight.Medium),
    Font(R.font.ibm_plex_sans_semibold, FontWeight.SemiBold),
    Font(R.font.ibm_plex_sans_bold,     FontWeight.Bold),
)

val PlexMono = FontFamily(
    Font(R.font.ibm_plex_mono_regular,  FontWeight.Normal),
    Font(R.font.ibm_plex_mono_medium,   FontWeight.Medium),
    Font(R.font.ibm_plex_mono_semibold, FontWeight.SemiBold),
)

private val tightLineHeight = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.None,
)

/* Semantic styles consumed directly by the AHC composables. Names map to the
 * HTML classes they replace, so the visual hierarchy is 1:1. */
object LlText {

    // --- Serif display ---
    val appBarTitle = TextStyle(            // .appbar-title
        fontFamily = SourceSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp, letterSpacing = (-0.02).em, lineHeight = 24.sp,
        color = LlColor.Ink,
    )
    val heroVerdict = TextStyle(            // .vhero-vt
        fontFamily = SourceSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp, letterSpacing = (-0.01).em, color = LlColor.Ink,
    )
    val emptyTitle = TextStyle(             // .empty-h / .cd-over-t
        fontFamily = SourceSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp, letterSpacing = (-0.01).em, color = LlColor.Ink,
    )
    val errorTitle = TextStyle(             // .fserr-h
        fontFamily = SourceSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, letterSpacing = (-0.015).em, lineHeight = 26.sp,
        color = LlColor.Ink,
    )
    val noteBody = TextStyle(               // .anote-body (advocate's note)
        fontFamily = SourceSerif, fontWeight = FontWeight.Normal,
        fontSize = 14.sp, lineHeight = 23.sp, color = LlColor.Ink,
    )

    // --- Sans UI ---
    val eyebrow = TextStyle(                // .appbar-eyebrow / kicker
        fontFamily = PlexSans, fontWeight = FontWeight.Bold,
        fontSize = 9.5.sp, letterSpacing = 0.12.em, color = LlColor.InkFaint,
    )
    val sectionHeader = TextStyle(          // .dsec-t
        fontFamily = PlexSans, fontWeight = FontWeight.Bold,
        fontSize = 10.5.sp, letterSpacing = 0.1.em, color = LlColor.Ink,
    )
    val bodyTitle = TextStyle(              // .finding-t / .advc-n / kv strong
        fontFamily = PlexSans, fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp, color = LlColor.Ink,
    )
    val body = TextStyle(                   // .finding-x / .cd-sub / generic body
        fontFamily = PlexSans, fontWeight = FontWeight.Normal,
        fontSize = 12.5.sp, lineHeight = 19.sp, color = LlColor.InkMuted,
    )
    val bodyStrong = TextStyle(             // .hero-status / verdict-t
        fontFamily = PlexSans, fontWeight = FontWeight.Bold,
        fontSize = 13.5.sp, color = LlColor.Ink,
    )
    val label = TextStyle(                  // .kv-k / step-t / small body
        fontFamily = PlexSans, fontWeight = FontWeight.Normal,
        fontSize = 11.5.sp, color = LlColor.InkMuted,
    )
    val button = TextStyle(                 // .btn
        fontFamily = PlexSans, fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp, letterSpacing = 0.05.em,
    )

    // --- Mono metadata ---
    val mono = TextStyle(                   // .cd-eta / .att-m / .refno
        fontFamily = PlexMono, fontWeight = FontWeight.Normal,
        fontSize = 10.5.sp, letterSpacing = 0.03.em, color = LlColor.InkFaint,
    )
    val monoStamp = TextStyle(              // .tl-m / docview-pg
        fontFamily = PlexMono, fontWeight = FontWeight.Normal,
        fontSize = 10.sp, color = LlColor.InkFaint,
    )
    val heroScore = TextStyle(              // .vscore (the 0–100 number)
        fontFamily = PlexMono, fontWeight = FontWeight.SemiBold,
        fontSize = 42.sp, letterSpacing = (-0.03).em, lineHeight = 40.sp,
    )
    val countdownNum = TextStyle(           // .cd-num
        fontFamily = PlexMono, fontWeight = FontWeight.SemiBold,
        fontSize = 40.sp, letterSpacing = (-0.02).em, lineHeight = 40.sp,
        color = LlColor.Ink,
    )
}

/* A minimal Material3 Typography so MaterialTheme defaults stay on-brand if a
 * stock M3 component is dropped in. Custom screens use LlText directly. */
val LlTypography = Typography(
    titleLarge = LlText.appBarTitle,
    titleMedium = LlText.heroVerdict,
    bodyLarge = LlText.body.copy(fontSize = 14.sp),
    bodyMedium = LlText.body,
    labelLarge = LlText.button.copy(color = LlColor.Ink),
    labelSmall = LlText.eyebrow,
)
